#!/bin/sh 
 ANDROID_ID=fda25cdd1d58399d
 echo "android_id=$ANDROID_ID" >> /data/android_sh.log 
 settings put secure android_id $ANDROID_ID 
 echo "settings put secure android_id $ANDROID_ID" >> /data/android_sh.log
