#! /bin/sh 

settings put global wifi_mac 04:5c:14:33:0a:49
dg config -a net.if.mac=04:5c:14:33:0a:49
